// dialogs.dart
import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:clipboard/clipboard.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:xterm/xterm.dart';
import 'package:xodos/l10n/app_localizations.dart';
import 'core_classes.dart';
import 'constants.dart';
import 'constants.dart';
import 'default_values.dart';
import 'core_classes.dart';
import 'pages.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:xodos/l10n/app_localizations.dart';

// DXVK Installer class with HUD settings to /opt/hud and automatic vkd3d/d8vk extraction
class DxvkDialog extends StatefulWidget {
  @override
  _DxvkDialogState createState() => _DxvkDialogState();
}

class _DxvkDialogState extends State<DxvkDialog> {
  String? _selectedDxvk;
  List<String> _dxvkFiles = [];
  String? _dxvkDirectory;
  bool _isLoading = true;
  
  // Current switch states
  bool _currentMangohudEnabled = false;
  bool _currentDxvkHudEnabled = false;
  
  // Saved states from SharedPreferences
  bool _savedMangohudEnabled = false;
  bool _savedDxvkHudEnabled = false;
  String? _savedSelectedDxvk;

  @override
  void initState() {
    super.initState();
    _loadSavedPreferences();
    _loadDxvkFiles();
  }

  Future<void> _loadSavedPreferences() async {
    try {
      // Load saved HUD preferences
      _savedMangohudEnabled = G.prefs.getBool('mangohud_enabled') ?? false;
      _savedDxvkHudEnabled = G.prefs.getBool('dxvkhud_enabled') ?? false;
      
      // Load saved DXVK selection
      _savedSelectedDxvk = G.prefs.getString('selected_dxvk');
      
      // Set current states from saved values
      setState(() {
        _currentMangohudEnabled = _savedMangohudEnabled;
        _currentDxvkHudEnabled = _savedDxvkHudEnabled;
      });
    } catch (e) {
      print('Error loading preferences: $e');
    }
  }

  Future<void> _savePreferences() async {
    await G.prefs.setBool('mangohud_enabled', _currentMangohudEnabled);
    await G.prefs.setBool('dxvkhud_enabled', _currentDxvkHudEnabled);
    if (_selectedDxvk != null) {
      await G.prefs.setString('selected_dxvk', _selectedDxvk!);
    }
  }

  bool get _hasHudChanged {
    return _currentMangohudEnabled != _savedMangohudEnabled ||
           _currentDxvkHudEnabled != _savedDxvkHudEnabled;
  }

  bool get _hasDxvkChanged {
    return _selectedDxvk != null && _selectedDxvk != _savedSelectedDxvk;
  }

  Future<void> _writeHudSettings() async {
    // Switch to terminal tab
    G.pageIndex.value = 0;
    
    // Wait a moment for tab switch
    await Future.delayed(const Duration(milliseconds: 300));
    
    // Clear the hud file first
    Util.termWrite("echo '' > /opt/hud");
    await Future.delayed(const Duration(milliseconds: 50));
    
    // Write HUD settings to /opt/hud
    Util.termWrite("echo '================================'");
    await Future.delayed(const Duration(milliseconds: 50));
    
    // Apply MANGOHUD settings
    if (_currentMangohudEnabled) {
      Util.termWrite("echo 'export MANGOHUD=1' >> /opt/hud");
      await Future.delayed(const Duration(milliseconds: 50));
      Util.termWrite("echo 'export MANGOHUD_DLSYM=1' >> /opt/hud");
      await Future.delayed(const Duration(milliseconds: 50));
      Util.termWrite("echo '# MANGOHUD enabled' >> /opt/hud");
    } else {
      Util.termWrite("echo 'export MANGOHUD=0' >> /opt/hud");
      await Future.delayed(const Duration(milliseconds: 50));
      Util.termWrite("echo 'export MANGOHUD_DLSYM=0' >> /opt/hud");
      await Future.delayed(const Duration(milliseconds: 50));
      Util.termWrite("echo '# MANGOHUD disabled' >> /opt/hud");
    }
    
    // Apply DXVK_HUD settings
    if (_currentDxvkHudEnabled) {
      Util.termWrite("echo 'export DXVK_HUD=fps,version,devinfo' >> /opt/hud");
      await Future.delayed(const Duration(milliseconds: 50));
      Util.termWrite("echo '# DXVK HUD enabled' >> /opt/hud");
    } else {
      Util.termWrite("echo 'export DXVK_HUD=0' >> /opt/hud");
      await Future.delayed(const Duration(milliseconds: 50));
      Util.termWrite("echo '# DXVK HUD disabled' >> /opt/hud");
    }
    
    Util.termWrite("echo 'HUD settings saved to /opt/hud'");
    await Future.delayed(const Duration(milliseconds: 50));
    Util.termWrite("echo '================================'");
  }

  Future<void> _extractDxvk() async {
    try {
      if (_selectedDxvk == null || _dxvkDirectory == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Please select a DXVK version'),
            duration: const Duration(seconds: 2),
          ),
        );
        return;
      }
      
      final dxvkPath = '$_dxvkDirectory/$_selectedDxvk';
      final file = File(dxvkPath);
      
      // Check if file exists
      if (!await file.exists()) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('File not found: $dxvkPath'),
            duration: const Duration(seconds: 3),
          ),
        );
        return;
      }
      
      // First, save preferences
      await _savePreferences();
      
      // Write HUD settings if changed
      if (_hasHudChanged) {
        await _writeHudSettings();
      }
      
      // Close dialog
      Navigator.of(context).pop();
      
      // Switch to terminal tab
      G.pageIndex.value = 0;
      
      // Wait a moment for tab switch
      await Future.delayed(const Duration(milliseconds: 300));
      
      // Extract DXVK and related files
      await _extractDxvkAndRelated();
      
    } catch (e) {
      print('Error in _extractDxvk: $e');
      // Ensure dialog closes even on error
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop();
      }
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error during extraction: $e'),
          duration: const Duration(seconds: 5),
        ),
      );
    }
  }

  Future<void> _extractDxvkAndRelated() async {
    // Check if we need to extract DXVK
    if (_hasDxvkChanged && _selectedDxvk != null) {
      // Extract the main DXVK file
      await _extractSingleFile(_selectedDxvk!, 'DXVK');
      
      // Check if the selected file has "dxvk" in its name (case insensitive)
      bool isDxvkFile = _selectedDxvk!.toLowerCase().contains('dxvk');
      
      // Only extract vkd3d and d8vk if the main file is a DXVK file
      if (isDxvkFile) {
        // Check and extract vkd3d if available (any file with 'vkd3d' in the name)
        final vkd3dFiles = await _findRelatedFiles('vkd3d');
        for (final vkd3dFile in vkd3dFiles) {
          await _extractSingleFile(vkd3dFile, 'VKD3D');
        }
        
        // Check and extract d8vk if available (any file with 'd8vk' in the name)
        final d8vkFiles = await _findRelatedFiles('d8vk');
        for (final d8vkFile in d8vkFiles) {
          await _extractSingleFile(d8vkFile, 'D8VK');
        }
      }
    } else {
      Util.termWrite("echo 'DXVK already installed: $_selectedDxvk'");
      await Future.delayed(const Duration(milliseconds: 50));
      Util.termWrite("echo '================================'");
    }
  }

  Future<void> _extractSingleFile(String fileName, String fileType) async {
    Util.termWrite("echo '================================'");
    await Future.delayed(const Duration(milliseconds: 50));
    
    Util.termWrite("echo 'Extracting $fileType: $fileName'");
    await Future.delayed(const Duration(milliseconds: 50));
    
    // Create target directory if it doesn't exist
    Util.termWrite("mkdir -p /home/xodos/.wine/drive_c/windows");
    await Future.delayed(const Duration(milliseconds: 50));
    
    // Extract based on file type
    String containerPath = "/wincomponents/d3d/$fileName";
    
    if (fileName.endsWith('.zip')) {
      Util.termWrite("unzip -o '$containerPath' -d '/home/xodos/.wine/drive_c/windows'");
    } else if (fileName.endsWith('.7z')) {
      Util.termWrite("7z x '$containerPath' -o'/home/xodos/.wine/drive_c/windows' -y");
    } else {
      // Assume it's a tar archive (most common for DXVK)
      Util.termWrite("tar -xaf '$containerPath' -C '/home/xodos/.wine/drive_c/windows'");
    }
    
    await Future.delayed(const Duration(milliseconds: 50));
    
    Util.termWrite("echo '$fileType extraction complete!'");
    await Future.delayed(const Duration(milliseconds: 50));
  }

  Future<List<String>> _findRelatedFiles(String pattern) async {
    if (_dxvkDirectory == null) return [];
    
    try {
      final dir = Directory(_dxvkDirectory!);
      final files = await dir.list().toList();
      
      return files
          .where((file) => file is File)
          .map((file) => file.path.split('/').last)
          .where((fileName) => fileName.toLowerCase().contains(pattern.toLowerCase()))
          .where((fileName) => RegExp(r'\.(tzst|tar\.gz|tgz|tar\.xz|txz|tar|zip|7z)$').hasMatch(fileName))
          .toList();
    } catch (e) {
      print('Error finding related files: $e');
      return [];
    }
  }

  Future<void> _cancelDialog() async {
    // Save preferences first
    await _savePreferences();
    
    // Write HUD settings if changed
    if (_hasHudChanged) {
      await _writeHudSettings();
      
      // Show confirmation
      WidgetsBinding.instance.addPostFrameCallback((_) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('HUD settings saved to /opt/hud'),
            duration: const Duration(seconds: 2),
          ),
        );
      });
    }
    
    // Close dialog
    Navigator.of(context).pop();
  }

  Future<void> _loadDxvkFiles() async {
    try {
      // Look in the container's wincomponents directory
      String containerDir = "${G.dataPath}/containers/${G.currentContainer}";
      String hostDir = "$containerDir/wincomponents/d3d";
      
      final dir = Directory(hostDir);
      if (!await dir.exists()) {
        print('DXVK directory not found at: $hostDir');
        setState(() {
          _dxvkFiles = [];
          _isLoading = false;
        });
        return;
      }
      
      _dxvkDirectory = hostDir;
      print('Found DXVK directory at: $hostDir');
      
      final files = await dir.list().toList();
      
      // Accept various archive formats
      final dxvkFiles = files
          .where((file) => file is File && 
              RegExp(r'\.(tzst|tar\.gz|tgz|tar\.xz|txz|tar|zip|7z)$').hasMatch(file.path))
          .map((file) => file.path.split('/').last)
          .toList();
      
      setState(() {
        _dxvkFiles = dxvkFiles;
        if (dxvkFiles.isNotEmpty) {
          // Load saved DXVK selection or use first
          _selectedDxvk = _savedSelectedDxvk ?? dxvkFiles.first;
        }
        _isLoading = false;
      });
    } catch (e) {
      print('Error loading DXVK files: $e');
      setState(() {
        _dxvkFiles = [];
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLandscape = MediaQuery.of(context).orientation == Orientation.landscape;
    
    return AlertDialog(
      title: const Text('Install DXVK'),
      content: ConstrainedBox(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * (isLandscape ? 0.8 : 0.6),
          minWidth: MediaQuery.of(context).size.width * (isLandscape ? 0.6 : 0.8),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (_isLoading)
                const Padding(
                  padding: EdgeInsets.all(20.0),
                  child: Center(child: CircularProgressIndicator()),
                ),
              if (!_isLoading && _dxvkFiles.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      const Icon(Icons.error_outline, color: Colors.orange, size: 48),
                      const SizedBox(height: 16),
                      const Text(
                        'No DXVK files found',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Please place DXVK files in:\n/wincomponents/d3d/',
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      if (_dxvkDirectory != null)
                        Text(
                          'Directory: $_dxvkDirectory',
                          style: const TextStyle(fontSize: 12, color: Colors.grey),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                        ),
                    ],
                  ),
                ),
              if (!_isLoading && _dxvkFiles.isNotEmpty)
                Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    DropdownButtonFormField<String>(
                      value: _selectedDxvk,
                      decoration: const InputDecoration(
                        labelText: 'Select DXVK Version',
                        border: OutlineInputBorder(),
                      ),
                      items: _dxvkFiles.map((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          _selectedDxvk = newValue;
                        });
                      },
                    ),
                    const SizedBox(height: 16),
                    
                    // HUD Settings Section
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.cardDark,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'HUD Settings (Saved to /opt/hud)',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: AppColors.primaryPurple,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Divider(height: 1),
                          const SizedBox(height: 12),
                          
                          // MANGOHUD Switch
                          SwitchListTile(
                            dense: isLandscape,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
                            title: const Text(
                              'MANGOHUD',
                              style: TextStyle(fontSize: 14),
                            ),
                            subtitle: const Text(
                              'Overlay for monitoring FPS, CPU, GPU, etc.',
                              style: TextStyle(fontSize: 12),
                            ),
                            value: _currentMangohudEnabled,
                            onChanged: (value) {
                              setState(() {
                                _currentMangohudEnabled = value;
                              });
                            },
                          ),
                          
                          // DXVK HUD Switch
                          SwitchListTile(
                            dense: isLandscape,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
                            title: const Text(
                              'DXVK HUD',
                              style: TextStyle(fontSize: 14),
                            ),
                            subtitle: const Text(
                              'DXVK overlay showing FPS, version, device info',
                              style: TextStyle(fontSize: 12),
                            ),
                            value: _currentDxvkHudEnabled,
                            onChanged: (value) {
                              setState(() {
                                _currentDxvkHudEnabled = value;
                              });
                            },
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // Auto-extraction info
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.green),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.info_outline, color: Colors.green, size: 20),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'installing: DXVK, VKD3D, and D8VK files will be Installed together',
                              style: TextStyle(
                                fontSize: isLandscape ? 12 : 14,
                                color: Colors.green,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // Changes indicator
                    if (_hasHudChanged || _hasDxvkChanged)
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.blue.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.blue),
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.info_outline,
                              color: Colors.blue,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                _hasHudChanged && _hasDxvkChanged
                                    ? 'HUD settings and DXVK will be updated'
                                    : _hasHudChanged
                                        ? 'HUD settings will be saved to /opt/hud'
                                        : 'DXVK will be extracted',
                                style: TextStyle(
                                  fontSize: isLandscape ? 12 : 14,
                                  color: Colors.blue,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _cancelDialog,
          child: const Text('Cancel'),
        ),
        if (_dxvkFiles.isNotEmpty && !_isLoading && _selectedDxvk != null)
          ElevatedButton(
            onPressed: _extractDxvk,
            child: const Text('Install'),
          ),
      ],
      scrollable: true,
    );
  }
}

/// Environment Dialog
class EnvironmentDialog extends StatefulWidget {
  @override
  _EnvironmentDialogState createState() => _EnvironmentDialogState();
}

class _EnvironmentDialogState extends State<EnvironmentDialog> {
  // Box64 Dynarec variables (updated with new switches)
  final List<Map<String, dynamic>> _dynarecVariables = [
    {"name": "BOX64_DYNAREC_SAFEFLAGS", "values": ["0", "1", "2"], "defaultValue": "2"},
    {"name": "BOX64_DYNAREC_FASTNAN", "values": ["0", "1"], "toggleSwitch": true, "defaultValue": "1"},
    {"name": "BOX64_DYNAREC_FASTROUND", "values": ["0", "1", "2"], "defaultValue": "1"},
    {"name": "BOX64_DYNAREC_X87DOUBLE", "values": ["0", "1"], "toggleSwitch": true, "defaultValue": "0"},
    {"name": "BOX64_DYNAREC_BIGBLOCK", "values": ["0", "1", "2", "3"], "defaultValue": "1"},
    {"name": "BOX64_DYNAREC_STRONGMEM", "values": ["0", "1", "2", "3"], "defaultValue": "0"},
    {"name": "BOX64_DYNAREC_FORWARD", "values": ["0", "128", "256", "512", "1024"], "defaultValue": "128"},
    {"name": "BOX64_DYNAREC_CALLRET", "values": ["0", "1"], "toggleSwitch": true, "defaultValue": "1"},
    {"name": "BOX64_DYNAREC_WAIT", "values": ["0", "1"], "toggleSwitch": true, "defaultValue": "1"},
    {"name": "BOX64_DYNAREC_NATIVEFLAGS", "values": ["0", "1"], "toggleSwitch": true, "defaultValue": "0"},
    {"name": "BOX64_DYNAREC_WEAKBARRIER", "values": ["0", "1", "2"], "defaultValue": "0"},
    // New switches
    {"name": "BOX64_MMAP32", "values": ["0", "1"], "toggleSwitch": true, "defaultValue": "0"},
    {"name": "BOX64_AVX", "values": ["0", "1"], "toggleSwitch": true, "defaultValue": "0"},
    {"name": "BOX64_UNITYPLAYER", "values": ["0", "1"], "toggleSwitch": true, "defaultValue": "0"},
  ];

  // Box64 presets
  final Map<String, Map<String, String>> _box64Presets = {
    'Stability': {
      'BOX64_DYNAREC_SAFEFLAGS': '2',
      'BOX64_DYNAREC_FASTNAN': '0',
      'BOX64_DYNAREC_FASTROUND': '0',
      'BOX64_DYNAREC_X87DOUBLE': '1',
      'BOX64_DYNAREC_BIGBLOCK': '0',
      'BOX64_DYNAREC_STRONGMEM': '2',
      'BOX64_DYNAREC_FORWARD': '128',
      'BOX64_DYNAREC_CALLRET': '0',
      'BOX64_DYNAREC_WAIT': '0',
      'BOX64_AVX': '0',
      'BOX64_UNITYPLAYER': '1',
      'BOX64_MMAP32': '0',
    },
    'Compatibility': {
      'BOX64_DYNAREC_SAFEFLAGS': '2',
      'BOX64_DYNAREC_FASTNAN': '0',
      'BOX64_DYNAREC_FASTROUND': '0',
      'BOX64_DYNAREC_X87DOUBLE': '1',
      'BOX64_DYNAREC_BIGBLOCK': '0',
      'BOX64_DYNAREC_STRONGMEM': '1',
      'BOX64_DYNAREC_FORWARD': '128',
      'BOX64_DYNAREC_CALLRET': '0',
      'BOX64_DYNAREC_WAIT': '1',
      'BOX64_AVX': '0',
      'BOX64_UNITYPLAYER': '1',
      'BOX64_MMAP32': '0',
    },
    'Intermediate': {
      'BOX64_DYNAREC_SAFEFLAGS': '2',
      'BOX64_DYNAREC_FASTNAN': '1',
      'BOX64_DYNAREC_FASTROUND': '0',
      'BOX64_DYNAREC_X87DOUBLE': '1',
      'BOX64_DYNAREC_BIGBLOCK': '1',
      'BOX64_DYNAREC_STRONGMEM': '0',
      'BOX64_DYNAREC_FORWARD': '128',
      'BOX64_DYNAREC_CALLRET': '1',
      'BOX64_DYNAREC_WAIT': '1',
      'BOX64_AVX': '0',
      'BOX64_UNITYPLAYER': '0',
      'BOX64_MMAP32': '1',
    },
  };

  // Core checkboxes - will be initialized with actual CPU count
  List<bool> _coreSelections = [];
  int _availableCores = 8; // Default, will be updated
  
  // Wine Esync switch
  bool _wineEsyncEnabled = false;
  
  // Custom variables
  List<Map<String, String>> _customVariables = [];
  String _selectedKnownVariable = '';
  final List<String> _knownWineVariables = [
    'WINEARCH',
    'WINEDEBUG',
    'WINEPREFIX',
    'WINEESYNC',
    'WINEFSYNC',
    'WINE_NOBLOB',
    'WINE_NO_CRASH_DIALOG',
    'WINEDLLOVERRIDES',
    'WINEDLLPATH',
    'WINE_MONO_CACHE_DIR',
    'WINE_GECKO_CACHE_DIR',
    'WINEDISABLE',
    'WINE_ENABLE'
  ];
  
  // Debug settings
  bool _debugEnabled = false;
  String _winedebugValue = '-all'; // Default value
  final List<String> _winedebugOptions = [
    '-all', 'err', 'warn', 'fixme', 'all', 'trace', 'message', 'heap', 'fps'
  ];
  
  // Current custom variable being added
  String _newVarName = '';
  String _newVarValue = '';

  @override
  void initState() {
    super.initState();
    _initializeCores();
    _loadSavedSettings();
  }

  Future<void> _initializeCores() async {
    try {
      // Get available processor count like Winlator does
      // We'll use Platform.numberOfProcessors for Dart
      _availableCores = Platform.numberOfProcessors;
      
      // Initialize core selections with actual available cores
      setState(() {
        _coreSelections = List.generate(_availableCores, (index) => true);
      });
    } catch (e) {
      print('Error getting CPU count: $e');
      // Fallback to 8 cores if we can't detect
      _availableCores = 8;
      _coreSelections = List.generate(8, (index) => true);
    }
  }

  Future<void> _loadSavedSettings() async {
    try {
      // Load core selections
      final savedCores = G.prefs.getString('environment_cores');
      if (savedCores != null && savedCores.isNotEmpty) {
        _parseCoreSelections(savedCores);
      } else {
        // Default: all cores selected
        setState(() {
          _coreSelections = List.generate(_availableCores, (index) => true);
        });
      }
      
      // Load wine esync
      _wineEsyncEnabled = G.prefs.getBool('environment_wine_esync') ?? false;
      
      // Load debug setting
      _debugEnabled = G.prefs.getBool('environment_debug') ?? false;
      
      // Load WINEDEBUG value
      _winedebugValue = G.prefs.getString('environment_winedebug') ?? '-all';
      
      // Load custom variables
      final savedVars = G.prefs.getStringList('environment_custom_vars') ?? [];
      _customVariables = savedVars.map((varStr) {
        final parts = varStr.split('=');
        return {'name': parts[0], 'value': parts.length > 1 ? parts[1] : ''};
      }).toList();
      
      setState(() {});
    } catch (e) {
      print('Error loading environment settings: $e');
    }
  }

  void _parseCoreSelections(String coreString) {
    try {
      // Reset all cores to false
      _coreSelections = List.generate(_availableCores, (index) => false);
      
      if (coreString.contains(',')) {
        // Comma-separated list (like "0,1,3")
        final selectedIndices = coreString.split(',');
        for (final indexStr in selectedIndices) {
          final index = int.tryParse(indexStr);
          if (index != null && index < _availableCores) {
            _coreSelections[index] = true;
          }
        }
      } else if (coreString.contains('-')) {
        // Range format (like "0-7")
        final parts = coreString.split('-');
        final start = int.tryParse(parts[0]) ?? 0;
        final end = int.tryParse(parts[1]) ?? (_availableCores - 1);
        
        for (int i = start; i <= end && i < _availableCores; i++) {
          _coreSelections[i] = true;
        }
      }
    } catch (e) {
      print('Error parsing core selections: $e');
    }
  }

  String _getCoreString() {
    // Winlator-style: comma-separated list of selected cores
    final selectedIndices = <int>[];
    for (int i = 0; i < _availableCores; i++) {
      if (_coreSelections[i]) {
        selectedIndices.add(i);
      }
    }
    
    if (selectedIndices.isEmpty) {
      return "0";
    }
    
    // Return comma-separated list
    return selectedIndices.join(',');
  }

  Future<void> _saveSettings() async {
    try {
      // Save to SharedPreferences
      await G.prefs.setString('environment_cores', _getCoreString());
      await G.prefs.setBool('environment_wine_esync', _wineEsyncEnabled);
      await G.prefs.setBool('environment_debug', _debugEnabled);
      await G.prefs.setString('environment_winedebug', _winedebugValue);
      
      // Save custom variables
      final varStrings = _customVariables.map((varMap) => '${varMap['name']}=${varMap['value']}').toList();
      await G.prefs.setStringList('environment_custom_vars', varStrings);
      
      // Save dynarec settings
      for (final variable in _dynarecVariables) {
        final name = variable['name'] as String;
        final currentValue = variable['currentValue'] ?? variable['defaultValue'];
        await G.prefs.setString('dynarec_$name', currentValue);
      }
      
      // Apply settings via terminal
      await _applyEnvironmentSettings();
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Environment settings saved and applied!'),
          duration: const Duration(seconds: 2),
        ),
      );
      Navigator.of(context).pop();
      
    } catch (e) {
      print('Error saving environment settings: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error saving settings: $e'),
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  Future<void> _applyEnvironmentSettings() async {
    // Switch to terminal tab
    G.pageIndex.value = 0;
    await Future.delayed(const Duration(milliseconds: 300));
    
    // Clear existing files
    Util.termWrite("echo '' > /opt/dyna");
    Util.termWrite("echo '' > /opt/sync");
    Util.termWrite("echo '' > /opt/cores");
    Util.termWrite("echo '' > /opt/env");
    Util.termWrite("echo '' > /opt/dbg");
    Util.termWrite("echo '' > /opt/hud");
    
    await Future.delayed(const Duration(milliseconds: 100));
    
    // Apply Box64 Dynarec settings
    for (final variable in _dynarecVariables) {
      final name = variable['name'] as String;
      final defaultValue = variable['defaultValue'] as String;
      final savedValue = G.prefs.getString('dynarec_$name') ?? defaultValue;
      
      Util.termWrite("echo 'export $name=$savedValue' >> /opt/dyna");
      await Future.delayed(const Duration(milliseconds: 10));
    }
    
    // Apply Wine Esync settings
    if (_wineEsyncEnabled) {
      Util.termWrite("echo 'export WINEESYNC=1' >> /opt/sync");
      Util.termWrite("echo 'export WINEESYNC_TERMUX=1' >> /opt/sync");
    } else {
      Util.termWrite("echo 'export WINEESYNC=0' >> /opt/sync");
      Util.termWrite("echo 'export WINEESYNC_TERMUX=0' >> /opt/sync");
    }
    
    // Apply Core settings
    Util.termWrite("echo 'export PRIMARY_CORES=${_getCoreString()}' >> /opt/cores");
    
    // Apply custom variables
    for (final variable in _customVariables) {
      Util.termWrite("echo 'export ${variable['name']}=${variable['value']}' >> /opt/env");
      await Future.delayed(const Duration(milliseconds: 10));
    }
    
    // Apply Debug settings
    if (_debugEnabled) {
      // Debug ON (verbose mode)
      Util.termWrite("echo 'export MESA_NO_ERROR=0' >> /opt/dbg");
      Util.termWrite("echo 'export WINEDEBUG=$_winedebugValue' >> /opt/dbg");
      Util.termWrite("echo 'export BOX64_LOG=1' >> /opt/dbg");
      Util.termWrite("echo 'export BOX64_NOBANNER=0' >> /opt/dbg");
      Util.termWrite("echo 'export BOX64_SHOWSEGV=1' >> /opt/dbg");
      Util.termWrite("echo 'export BOX64_DLSYM_ERROR=1' >> /opt/dbg");
      Util.termWrite("echo 'export BOX64_DYNAREC_MISSING=1' >> /opt/dbg");
    } else {
      // Debug OFF (quiet mode)
      Util.termWrite("echo 'export MESA_NO_ERROR=1' >> /opt/dbg");
      Util.termWrite("echo 'export WINEDEBUG=$_winedebugValue' >> /opt/dbg");
      Util.termWrite("echo 'export BOX64_LOG=0' >> /opt/dbg");
      Util.termWrite("echo 'export BOX64_NOBANNER=1' >> /opt/dbg");
      Util.termWrite("echo 'export BOX64_SHOWSEGV=0' >> /opt/dbg");
      Util.termWrite("echo 'export BOX64_DLSYM_ERROR=0' >> /opt/dbg");
      Util.termWrite("echo 'export BOX64_DYNAREC_MISSING=0' >> /opt/dbg");
    }
    
    Util.termWrite("echo '================================'");
    Util.termWrite("echo 'Environment settings applied!'");
    Util.termWrite("echo '================================'");
  }

  void _showDynarecDialog() {
    showDialog(
      context: context,
      builder: (context) {
        // Create a local copy of dynarec variables with current values
        final localVariables = _dynarecVariables.map((variable) {
          final name = variable['name'] as String;
          final defaultValue = variable['defaultValue'] as String;
          final savedValue = G.prefs.getString('dynarec_$name') ?? defaultValue;
          return {
            'name': name,
            'values': variable['values'],
            'defaultValue': defaultValue,
            'toggleSwitch': variable['toggleSwitch'] ?? false,
            'currentValue': savedValue,
          };
        }).toList();

        String selectedPreset = 'Custom';

        return StatefulBuilder(
          builder: (context, setState) {
            // Function to check if current values match any preset
            void _updatePresetSelection() {
              // Check if current values match any preset
              for (final presetName in _box64Presets.keys) {
                final preset = _box64Presets[presetName]!;
                bool matches = true;
                
                for (final variable in localVariables) {
                  final name = variable['name'] as String;
                  final currentValue = variable['currentValue'] as String;
                  
                  if (preset.containsKey(name) && preset[name] != currentValue) {
                    matches = false;
                    break;
                  }
                }
                
                if (matches) {
                  selectedPreset = presetName;
                  return;
                }
              }
              selectedPreset = 'Custom';
            }

            // Initialize preset selection
            _updatePresetSelection();

            return AlertDialog(
              title: const Text('Box64 Dynarec Settings'),
              content: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Preset dropdown
                      Card(
                        margin: const EdgeInsets.only(bottom: 16),
                        child: Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Preset',
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                              ),
                              const SizedBox(height: 8),
                              DropdownButton<String>(
                                value: selectedPreset,
                                isExpanded: true,
                                items: [
                                  const DropdownMenuItem<String>(
                                    value: 'Custom',
                                    child: Text('Custom'),
                                  ),
                                  ..._box64Presets.keys.map((presetName) {
                                    return DropdownMenuItem<String>(
                                      value: presetName,
                                      child: Text(presetName),
                                    );
                                  }).toList(),
                                ],
                                onChanged: (String? newValue) {
                                  if (newValue != null) {
                                    setState(() {
                                      selectedPreset = newValue;
                                      
                                      if (newValue != 'Custom') {
                                        final preset = _box64Presets[newValue]!;
                                        
                                        for (final variable in localVariables) {
                                          final name = variable['name'] as String;
                                          if (preset.containsKey(name)) {
                                            variable['currentValue'] = preset[name]!;
                                          }
                                        }
                                      }
                                    });
                                  }
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                      
                      // Dynarec variables
                      ...localVariables.map((variable) {
                        return _buildDynarecVariableWidget(
                          variable, 
                          setState,
                          localVariables, // Pass the localVariables list
                          onVariableChanged: () {
                            // When any variable changes manually, set preset to Custom
                            setState(() {
                              selectedPreset = 'Custom';
                            });
                          }
                        );
                      }).toList(),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cancel'),
                ),
                TextButton(
                  onPressed: () async {
                    // Save all dynarec settings
                    for (final variable in localVariables) {
                      final name = variable['name'] as String;
                      final currentValue = variable['currentValue'] as String;
                      await G.prefs.setString('dynarec_$name', currentValue);
                    }
                    
                    // Also update the main list
                    for (final localVar in localVariables) {
                      final index = _dynarecVariables.indexWhere((v) => v['name'] == localVar['name']);
                      if (index != -1) {
                        _dynarecVariables[index]['currentValue'] = localVar['currentValue'];
                      }
                    }
                    
                    Navigator.of(context).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Dynarec settings saved'),
                        duration: const Duration(seconds: 2),
                      ),
                    );
                  },
                  child: const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  // Update the function signature to include optional callback
  Widget _buildDynarecVariableWidget(
    Map<String, dynamic> variable, 
    StateSetter setState,
    List<Map<String, dynamic>> localVariables, {
    VoidCallback? onVariableChanged,
  }) {
    final name = variable['name'] as String;
    final values = variable['values'] as List<String>;
    final isToggle = variable['toggleSwitch'] == true;
    final currentValue = variable['currentValue'] as String;
    
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              name,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            if (isToggle)
              SwitchListTile(
                title: Text('Enabled (${currentValue == "1" ? "ON" : "OFF"})'),
                value: currentValue == "1",
                onChanged: (value) {
                  setState(() {
                    variable['currentValue'] = value ? "1" : "0";
                    onVariableChanged?.call();
                  });
                },
              )
            else
              DropdownButton<String>(
                value: currentValue,
                isExpanded: true,
                items: values.map((value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  if (newValue != null) {
                    setState(() {
                      variable['currentValue'] = newValue;
                      onVariableChanged?.call();
                    });
                  }
                },
              ),
          ],
        ),
      ),
    );
  }

  void _addCustomVariable() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Environment Variable'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Autocomplete<String>(
                optionsBuilder: (TextEditingValue textEditingValue) {
                  if (textEditingValue.text.isEmpty) {
                    return const Iterable<String>.empty();
                  }
                  return _knownWineVariables.where(
                    (variable) => variable.toLowerCase().contains(textEditingValue.text.toLowerCase()),
                  );
                },
                fieldViewBuilder: (
                  context,
                  textEditingController,
                  focusNode,
                  onFieldSubmitted,
                ) {
                  return TextFormField(
                    controller: textEditingController,
                    focusNode: focusNode,
                    decoration: const InputDecoration(
                      labelText: 'Variable Name',
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (value) {
                      _newVarName = value;
                    },
                  );
                },
                onSelected: (String selection) {
                  _newVarName = selection;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'Value',
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  _newVarValue = value;
                },
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              if (_newVarName.isNotEmpty && _newVarValue.isNotEmpty) {
                setState(() {
                  _customVariables.add({
                    'name': _newVarName,
                    'value': _newVarValue,
                  });
                  _newVarName = '';
                  _newVarValue = '';
                });
                Navigator.of(context).pop();
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Please enter both variable name and value'),
                    duration: Duration(seconds: 2),
                  ),
                );
              }
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  void _removeCustomVariable(int index) {
    setState(() {
      _customVariables.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Environment Settings'),
      content: SizedBox(
        width: double.maxFinite,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Box64 Dynarec Section
              Card(
                child: ListTile(
                  title: const Text('Box64 Dynarec'),
                  subtitle: const Text('Advanced emulation settings'),
                  trailing: const Icon(Icons.arrow_forward),
                  onTap: _showDynarecDialog,
                ),
              ),
              const SizedBox(height: 8),
              
              // Wine Esync Section
              Card(
                child: SwitchListTile(
                  title: const Text('Wine Esync'),
                  subtitle: const Text('Enable Wine Esync for better performance'),
                  value: _wineEsyncEnabled,
                  onChanged: (value) {
                    setState(() {
                      _wineEsyncEnabled = value;
                    });
                  },
                ),
              ),
              const SizedBox(height: 8),
              
              // Cores Section
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'CPU Cores',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Text('Available CPUs: $_availableCores'),
                      Text('Selected: ${_getCoreString()}'),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: List.generate(_availableCores, (index) {
                          return FilterChip(
                            label: Text('CPU$index'),
                            selected: _coreSelections[index],
                            onSelected: (selected) {
                              setState(() {
                                _coreSelections[index] = selected;
                              });
                            },
                          );
                        }),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          TextButton(
                            onPressed: () {
                              setState(() {
                                _coreSelections = List.generate(_availableCores, (index) => true);
                              });
                            },
                            child: const Text('Select All'),
                          ),
                          TextButton(
                            onPressed: () {
                              setState(() {
                                _coreSelections = List.generate(_availableCores, (index) => false);
                              });
                            },
                            child: const Text('Clear All'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              
              // Custom Variables Section
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Custom Variables',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      ..._customVariables.asMap().entries.map((entry) {
                        final index = entry.key;
                        final variable = entry.value;
                        return ListTile(
                          title: Text(variable['name'] ?? ''),
                          subtitle: Text(variable['value'] ?? ''),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _removeCustomVariable(index),
                          ),
                          dense: true,
                        );
                      }),
                      const SizedBox(height: 8),
                      OutlinedButton(
                        onPressed: _addCustomVariable,
                        child: const Text('Add Variable'),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              
              // Debug Section
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SwitchListTile(
                        title: const Text('Debug Mode'),
                        subtitle: _debugEnabled
                            ? const Text('Verbose logging enabled')
                            : const Text('Quiet mode - minimal logging'),
                        value: _debugEnabled,
                        onChanged: (value) {
                          setState(() {
                            _debugEnabled = value;
                          });
                        },
                      ),
                      if (_debugEnabled) ...[
                        const SizedBox(height: 12),
                        const Divider(),
                        const SizedBox(height: 8),
                        const Text(
                          'WINEDEBUG Level',
                          style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 8),
                        DropdownButtonFormField<String>(
                          value: _winedebugValue,
                          decoration: const InputDecoration(
                            labelText: 'WINEDEBUG',
                            border: OutlineInputBorder(),
                          ),
                          items: _winedebugOptions.map((option) {
                            return DropdownMenuItem<String>(
                              value: option,
                              child: Text(option),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              _winedebugValue = value ?? '-all';
                            });
                          },
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _saveSettings,
          child: const Text('Save & Apply'),
        ),
      ],
    );
  }
}

// GPU Drivers Dialog - Complete Fixed Version
class GpuDriversDialog extends StatefulWidget {
  @override
  _GpuDriversDialogState createState() => _GpuDriversDialogState();
}

class _GpuDriversDialogState extends State<GpuDriversDialog> {
  // Driver types
  String _selectedDriverType = 'virgl';
  String? _selectedDriverFile;
  List<String> _driverFiles = [];
  String? _driversDirectory;
  bool _isLoading = true;
  
  // Turnip options
  bool _useBuiltInTurnip = true;
  bool _driEnabled = false;
  
  // Settings
  bool _virglEnabled = false;
  bool _turnipEnabled = false;
  bool _dri3Enabled = false;
  String _defaultTurnipOpt = 'MESA_LOADER_DRIVER_OVERRIDE=zink TU_DEBUG=noconform';

  @override
  void initState() {
    super.initState();
    _loadSavedSettings();
    _loadDriverFiles();
  }

  Future<void> _loadSavedSettings() async {
    try {
      // Load existing graphics settings
      _virglEnabled = G.prefs.getBool('virgl') ?? false;
      _turnipEnabled = G.prefs.getBool('turnip') ?? false;
      _dri3Enabled = G.prefs.getBool('dri3') ?? false;
      
      // Load the default turnip opt
      String savedTurnipOpt = G.prefs.getString('defaultTurnipOpt') ?? 'MESA_LOADER_DRIVER_OVERRIDE=zink TU_DEBUG=noconform';
      _defaultTurnipOpt = _removeVkIcdFromEnvString(savedTurnipOpt);
      
      // If it's empty after cleaning, set a default
      if (_defaultTurnipOpt.isEmpty) {
        _defaultTurnipOpt = 'MESA_LOADER_DRIVER_OVERRIDE=zink TU_DEBUG=noconform';
      }
      
      // Load GPU driver specific settings
      _selectedDriverType = G.prefs.getString('gpu_driver_type') ?? 'virgl';
      _selectedDriverFile = G.prefs.getString('selected_gpu_driver');
      _useBuiltInTurnip = G.prefs.getBool('use_builtin_turnip') ?? true;
      _driEnabled = G.prefs.getBool('gpu_dri_enabled') ?? false;
      
      setState(() {});
    } catch (e) {
      print('Error loading GPU settings: $e');
    }
  }

  String _removeVkIcdFromEnvString(String envString) {
    // Remove VK_ICD_FILENAMES variable from the environment string
    // Split by space to separate environment variables
    List<String> envVars = envString.split(' ');
    
    // Filter out any variable that starts with VK_ICD_FILENAMES
    envVars.removeWhere((varStr) => varStr.trim().startsWith('VK_ICD_FILENAMES='));
    
    // Join back together
    return envVars.join(' ').trim();
  }

  Future<void> _saveAndExtract() async {
    try {
      // Save settings first
      await G.prefs.setString('gpu_driver_type', _selectedDriverType);
      if (_selectedDriverFile != null) {
        await G.prefs.setString('selected_gpu_driver', _selectedDriverFile!);
      }
      await G.prefs.setBool('use_builtin_turnip', _useBuiltInTurnip);
      await G.prefs.setBool('gpu_dri_enabled', _driEnabled);
      
      // Save existing graphics settings
      await G.prefs.setBool('virgl', _virglEnabled);
      await G.prefs.setBool('turnip', _turnipEnabled);
      await G.prefs.setBool('dri3', _dri3Enabled);
      
      // Clean and save the turnip opt
      String cleanTurnipOpt = _removeVkIcdFromEnvString(_defaultTurnipOpt);
      if (cleanTurnipOpt.isEmpty) {
        cleanTurnipOpt = 'MESA_LOADER_DRIVER_OVERRIDE=zink TU_DEBUG=noconform';
      }
      await G.prefs.setString('defaultTurnipOpt', cleanTurnipOpt);
      
      // Switch to terminal tab
      G.pageIndex.value = 0;
      await Future.delayed(const Duration(milliseconds: 300));
      
      // Extract driver if needed (custom driver selected)
      if (!(_selectedDriverType == 'turnip' && _useBuiltInTurnip) && 
          _selectedDriverFile != null) {
        await _extractDriver();
      } else {
        // Just apply settings without extraction
        await _applyGpuSettings();
      }
      
      // If VirGL is enabled, start the server
      if (_virglEnabled && _selectedDriverType == 'virgl') {
        final virglCommand = G.prefs.getString('defaultVirglCommand') ?? '--use-egl-surfaceless --use-gles --socket-path=\$CONTAINER_DIR/tmp/.virgl_test';
        await _startVirglServer(virglCommand);
      }
      
      // Close dialog
      Navigator.of(context).pop();
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('GPU driver settings saved and applied!'),
          duration: const Duration(seconds: 2),
        ),
      );
    } catch (e) {
      print('Error saving GPU settings: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error saving settings: $e'),
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  Future<void> _applyGpuSettings() async {
    // Switch to terminal tab
    G.pageIndex.value = 0;
    await Future.delayed(const Duration(milliseconds: 300));
    
    // Clear existing driver file
    Util.termWrite("echo '' > /opt/drv");
    
    // Apply settings based on driver type
    if (_selectedDriverType == 'turnip') {
      await _applyTurnipSettings();
    } else if (_selectedDriverType == 'virgl') {
      await _applyVirglSettings();
    } else if (_selectedDriverType == 'wrapper') {
      await _applyWrapperSettings();
    }
    
    Util.termWrite("echo '================================'");
    Util.termWrite("echo 'GPU driver settings applied!'");
    Util.termWrite("echo '================================'");
  }

  Future<void> _applyTurnipSettings() async {
    if (_useBuiltInTurnip) {
      // Built-in turnip - use the bundled driver
      Util.termWrite("echo 'export VK_ICD_FILENAMES=/home/tiny/.local/share/tiny/extra/freedreno_icd.aarch64.json' >> /opt/drv");
    } else if (_selectedDriverFile != null) {
      // Custom turnip driver - use the extracted driver
      Util.termWrite("echo 'export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/freedreno_icd.aarch64.json' >> /opt/drv");
    }
    
    // Set turnip environment if enabled
    if (_turnipEnabled) {
      // Clean the turnip opt to remove any VK_ICD_FILENAMES
      String cleanTurnipOpt = _removeVkIcdFromEnvString(_defaultTurnipOpt);
      
      if (cleanTurnipOpt.isNotEmpty) {
        Util.termWrite("echo 'export $cleanTurnipOpt' >> /opt/drv");
      }
      
      // Add DRI3 debug if DRI3 is disabled
      if (!_dri3Enabled) {
        Util.termWrite("echo 'export MESA_VK_WSI_DEBUG=sw' >> /opt/drv");
      }
    }
  }

  Future<void> _applyVirglSettings() async {
    if (_virglEnabled) {
      // Get VirGL server parameters
      final virglCommand = G.prefs.getString('defaultVirglCommand') ?? '--use-egl-surfaceless --use-gles --socket-path=\$CONTAINER_DIR/tmp/.virgl_test';
      final virglEnv = G.prefs.getString('defaultVirglOpt') ?? 'GALLIUM_DRIVER=virpipe';
      
      // Write VirGL environment to /opt/drv
      Util.termWrite("echo 'export $virglEnv' >> /opt/drv");
      await Future.delayed(const Duration(milliseconds: 50));
      
      // If we have a custom virgl driver file, we might need to set additional env vars
      if (_selectedDriverFile != null) {
        Util.termWrite("echo '# Custom VirGL driver: $_selectedDriverFile' >> /opt/drv");
      }
    }
  }

  Future<void> _startVirglServer(String virglCommand) async {
    // Switch to terminal tab first
    G.pageIndex.value = 0;
    await Future.delayed(const Duration(milliseconds: 300));
    
    // First, kill any existing virgl_test_server
    Util.termWrite("pkill -f virgl_test_server");
    await Future.delayed(const Duration(milliseconds: 100));
    
    // Start the VirGL server
    Util.termWrite("echo '================================'");
    await Future.delayed(const Duration(milliseconds: 50));
    
    Util.termWrite("echo 'Starting VirGL server...'");
    await Future.delayed(const Duration(milliseconds: 50));
    
    // Create the socket directory
    Util.termWrite("mkdir -p /tmp/.virgl_test");
    await Future.delayed(const Duration(milliseconds: 50));
    
    // Get the correct paths for the virgl_test_server binary
    // The binary is in the host's data directory, not in the container
    String dataDir = G.dataPath;
    String containerDir = "$dataDir/containers/${G.currentContainer}";
    
    // Replace $CONTAINER_DIR variable in the command
    String processedCommand = virglCommand.replaceAll('\$CONTAINER_DIR', containerDir);
    
    // Start the VirGL server from the host's binary location
    Util.termWrite("echo 'Using data directory: $dataDir'");
    await Future.delayed(const Duration(milliseconds: 50));
    
    Util.termWrite("echo 'Container directory: $containerDir'");
    await Future.delayed(const Duration(milliseconds: 50));
    
    // This will be executed on the host, not in the container
    // We need to use the host's virgl_test_server binary
    Util.termWrite("$dataDir/bin/virgl_test_server $processedCommand &");
    
    await Future.delayed(const Duration(milliseconds: 50));
    
    // Check if server started successfully
    Util.termWrite("sleep 1 && if pgrep -f virgl_test_server > /dev/null; then echo 'VirGL server started successfully'; else echo 'Failed to start VirGL server'; fi");
    
    await Future.delayed(const Duration(milliseconds: 50));
    Util.termWrite("echo '================================'");
  }

  Future<void> _applyWrapperSettings() async {
    // Wrapper drivers (like wine wrapper)
    if (_selectedDriverFile != null) {
      Util.termWrite("echo '# Using wrapper driver: $_selectedDriverFile' >> /opt/drv");
    }
  }

  Future<void> _extractDriver() async {
    try {
      if (_selectedDriverFile == null || _driversDirectory == null) {
        throw Exception('Please select a driver file');
      }
      
      final driverPath = '$_driversDirectory/$_selectedDriverFile';
      final file = File(driverPath);
      
      // Check if file exists
      if (!await file.exists()) {
        throw Exception('File not found: $driverPath');
      }
      
      // Switch to terminal tab
      G.pageIndex.value = 0;
      
      // Wait a moment for tab switch
      await Future.delayed(const Duration(milliseconds: 300));
      
      // Extract driver
      Util.termWrite("echo '================================'");
      await Future.delayed(const Duration(milliseconds: 50));
      
      Util.termWrite("echo 'Extracting GPU driver: $_selectedDriverFile'");
      await Future.delayed(const Duration(milliseconds: 50));
      
      Util.termWrite("echo '================================'");
      await Future.delayed(const Duration(milliseconds: 50));
      
      // Create target directory if it doesn't exist
      Util.termWrite("mkdir -p /usr/share/vulkan/icd.d");
      await Future.delayed(const Duration(milliseconds: 50));
      
      // Extract based on file type
      String containerPath = "/drivers/$_selectedDriverFile";
      
      if (_selectedDriverFile!.endsWith('.zip')) {
        Util.termWrite("unzip -o '$containerPath' -d '/usr'");
      } else if (_selectedDriverFile!.endsWith('.7z')) {
        Util.termWrite("7z x '$containerPath' -o'/usr' -y");
      } else if (_selectedDriverFile!.endsWith('.tar.gz') || _selectedDriverFile!.endsWith('.tgz')) {
        Util.termWrite("tar -xzf '$containerPath' -C '/usr'");
      } else if (_selectedDriverFile!.endsWith('.tar.xz') || _selectedDriverFile!.endsWith('.txz')) {
        Util.termWrite("tar -xJf '$containerPath' -C '/usr'");
      } else {
        // Assume it's a tar archive
        Util.termWrite("tar -xf '$containerPath' -C '/usr'");
      }
      
      await Future.delayed(const Duration(milliseconds: 50));
      
      // Apply GPU settings after extraction
      await _applyGpuSettings();
      
    } catch (e) {
      print('Error in _extractDriver: $e');
      // Show error but don't rethrow - let the dialog close
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error extracting driver: $e'),
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  Future<void> _loadDriverFiles() async {
    try {
      // Look in the container's drivers directory
      String containerDir = "${G.dataPath}/containers/${G.currentContainer}";
      String hostDir = "$containerDir/drivers";
      
      final dir = Directory(hostDir);
      if (!await dir.exists()) {
        print('Drivers directory not found at: $hostDir');
        setState(() {
          _driverFiles = [];
          _driversDirectory = hostDir;
          _isLoading = false;
        });
        return;
      }
      
      _driversDirectory = hostDir;
      print('Found drivers directory at: $hostDir');
      
      final files = await dir.list().toList();
      
      // Accept various archive formats
      final allDriverFiles = files
          .where((file) => file is File && 
              RegExp(r'\.(tzst|tar\.gz|tgz|tar\.xz|txz|tar|zip|7z|json|so|ko)$').hasMatch(file.path))
          .map((file) => file.path.split('/').last)
          .toList();
      
      setState(() {
        _driverFiles = allDriverFiles;
        if (allDriverFiles.isNotEmpty) {
          // Load saved driver selection
          _selectedDriverFile = G.prefs.getString('selected_gpu_driver');
          
          // If no saved selection, try to find one matching current driver type
          if (_selectedDriverFile == null) {
            _filterDriverFiles();
          }
        }
        _isLoading = false;
      });
    } catch (e) {
      print('Error loading driver files: $e');
      setState(() {
        _driverFiles = [];
        _isLoading = false;
      });
    }
  }

  void _filterDriverFiles() {
    // Filter files based on selected driver type
    List<String> filteredFiles = [];
    
    if (_selectedDriverType == 'turnip') {
      filteredFiles = _driverFiles.where((file) => 
          file.toLowerCase().contains('turnip') || 
          file.toLowerCase().contains('freedreno')).toList();
    } else if (_selectedDriverType == 'virgl') {
      filteredFiles = _driverFiles.where((file) => 
          file.toLowerCase().contains('virgl') || 
          file.toLowerCase().contains('virtio')).toList();
    } else if (_selectedDriverType == 'wrapper') {
      filteredFiles = _driverFiles.where((file) => 
          file.toLowerCase().contains('wrapper') || 
          file.toLowerCase().contains('wine')).toList();
    }
    
    // If we have filtered files, select the first one
    if (filteredFiles.isNotEmpty) {
      setState(() {
        _selectedDriverFile = filteredFiles.first;
      });
    }
  }

  void _onDriverTypeChanged(String? newType) {
    if (newType != null) {
      setState(() {
        _selectedDriverType = newType;
        // Reset selection when type changes
        _selectedDriverFile = null;
        _useBuiltInTurnip = (newType == 'turnip');
        _filterDriverFiles();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('GPU Drivers'),
      content: SizedBox(
        width: double.maxFinite,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Driver Type Selection
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Driver Type',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      DropdownButtonFormField<String>(
                        value: _selectedDriverType,
                        decoration: const InputDecoration(
                          labelText: 'Select Driver Type',
                          border: OutlineInputBorder(),
                        ),
                        items: [
                          DropdownMenuItem(
                            value: 'virgl',
                            child: Row(
                              children: [
                                Icon(Icons.hardware, color: Colors.blue),
                                SizedBox(width: 8),
                                Text('VirGL (Virtual GL)'),
                              ],
                            ),
                          ),
                          DropdownMenuItem(
                            value: 'turnip',
                            child: Row(
                              children: [
                                Icon(Icons.grain, color: Colors.purple),
                                SizedBox(width: 8),
                                Text('Turnip (Vulkan)'),
                              ],
                            ),
                          ),
                          DropdownMenuItem(
                            value: 'wrapper',
                            child: Row(
                              children: [
                                Icon(Icons.wrap_text, color: Colors.green),
                                SizedBox(width: 8),
                                Text('Wrapper'),
                              ],
                            ),
                          ),
                        ],
                        onChanged: _onDriverTypeChanged,
                      ),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 16),
              
              if (_selectedDriverType == 'virgl')
                Card(
                  child: ListTile(
                    title: const Text('VirGL Server'),
                    subtitle: Text(_virglEnabled ? 'Enabled - Click restart to start server' : 'Disabled - Enable VirGL above'),
                    trailing: IconButton(
                      icon: const Icon(Icons.refresh),
                      onPressed: () {
                        if (_virglEnabled) {
                          final virglCommand = G.prefs.getString('defaultVirglCommand') ?? '--use-egl-surfaceless --use-gles --socket-path=\$CONTAINER_DIR/tmp/.virgl_test';
                          _startVirglServer(virglCommand);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Restarting VirGL server...'),
                              duration: const Duration(seconds: 2),
                            ),
                          );
                        }
                      },
                    ),
                  ),
                ),
              const SizedBox(height: 16),
                          
              // Driver Settings Section
              if (_selectedDriverType == 'turnip') _buildTurnipSettings(),
              if (_selectedDriverType == 'virgl') _buildVirglSettings(),
              if (_selectedDriverType == 'wrapper') _buildWrapperSettings(),
              
              // Driver Files Selection (if not using built-in turnip)
              if (!(_selectedDriverType == 'turnip' && _useBuiltInTurnip))
                _buildDriverFileSelection(),
              
              // DRI Switch (for Turnip/VirGL)
              if (_selectedDriverType == 'turnip' || _selectedDriverType == 'virgl')
                Card(
                  child: SwitchListTile(
                    title: const Text('Enable DRI3'),
                    subtitle: const Text('Direct Rendering Infrastructure v3'),
                    value: _driEnabled,
                    onChanged: (value) {
                      setState(() {
                        _driEnabled = value;
                        if (_selectedDriverType == 'turnip') {
                          _dri3Enabled = value;
                        }
                      });
                    },
                  ),
                ),
              
              // Graphics Acceleration Toggles
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Graphics Acceleration',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      SwitchListTile(
                        title: const Text('Enable VirGL'),
                        subtitle: const Text('Virtual OpenGL acceleration'),
                        value: _virglEnabled,
                        onChanged: _selectedDriverType == 'virgl' ? (value) {
                          setState(() {
                            _virglEnabled = value;
                          });
                        } : null,
                      ),
                      SwitchListTile(
                        title: const Text('Enable Turnip/Zink'),
                        subtitle: const Text('Vulkan via Zink driver'),
                        value: _turnipEnabled,
                        onChanged: _selectedDriverType == 'turnip' ? (value) {
                          setState(() {
                            _turnipEnabled = value;
                            if (!value && _dri3Enabled) {
                              _dri3Enabled = false;
                            }
                          });
                        } : null,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _saveAndExtract,
          child: const Text('Save & Apply'),
        ),
      ],
    );
  }

  Widget _buildTurnipSettings() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Turnip Settings',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            // Horizontal radio buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: _useBuiltInTurnip ? Colors.blue.withOpacity(0.1) : Colors.transparent,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: _useBuiltInTurnip ? Colors.blue : Colors.grey,
                        width: 1,
                      ),
                    ),
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          _useBuiltInTurnip = true;
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Radio<bool>(
                              value: true,
                              groupValue: _useBuiltInTurnip,
                              onChanged: (value) {
                                setState(() {
                                  _useBuiltInTurnip = value ?? true;
                                });
                              },
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Built-in Turnip',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: _useBuiltInTurnip ? Colors.blue : Colors.grey,
                                    ),
                                  ),
                                  Text(
                                    'Use bundled driver',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: _useBuiltInTurnip ? Colors.blue : Colors.grey,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: !_useBuiltInTurnip ? Colors.purple.withOpacity(0.1) : Colors.transparent,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: !_useBuiltInTurnip ? Colors.purple : Colors.grey,
                        width: 1,
                      ),
                    ),
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          _useBuiltInTurnip = false;
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Radio<bool>(
                              value: false,
                              groupValue: _useBuiltInTurnip,
                              onChanged: (value) {
                                setState(() {
                                  _useBuiltInTurnip = value ?? false;
                                });
                              },
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Custom Driver',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: !_useBuiltInTurnip ? Colors.purple : Colors.grey,
                                    ),
                                  ),
                                  Text(
                                    'Extract from drivers folder',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: !_useBuiltInTurnip ? Colors.purple : Colors.grey,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            if (!_useBuiltInTurnip) ...[
              const SizedBox(height: 8),
              const Divider(),
              const SizedBox(height: 8),
              TextFormField(
                maxLines: 2,
                initialValue: _defaultTurnipOpt,
                decoration: const InputDecoration(
                  labelText: 'Turnip Environment Variables (without VK_ICD_FILENAMES)',
                  hintText: 'Example: MESA_LOADER_DRIVER_OVERRIDE=zink TU_DEBUG=noconform',
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  setState(() {
                    _defaultTurnipOpt = value;
                  });
                },
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildVirglSettings() {
    final defaultVirglCommand = G.prefs.getString('defaultVirglCommand') ?? '--use-egl-surfaceless --use-gles --socket-path=\$CONTAINER_DIR/tmp/.virgl_test';
    final defaultVirglOpt = G.prefs.getString('defaultVirglOpt') ?? 'GALLIUM_DRIVER=virpipe';
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'VirGL Settings',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            TextFormField(
              maxLines: 2,
              initialValue: defaultVirglCommand,
              decoration: const InputDecoration(
                labelText: 'VirGL Server Parameters',
                border: OutlineInputBorder(),
              ),
              onChanged: (value) async {
                await G.prefs.setString('defaultVirglCommand', value);
              },
            ),
            const SizedBox(height: 8),
            TextFormField(
              maxLines: 2,
              initialValue: defaultVirglOpt,
              decoration: const InputDecoration(
                labelText: 'VirGL Environment Variables',
                border: OutlineInputBorder(),
              ),
              onChanged: (value) async {
                await G.prefs.setString('defaultVirglOpt', value);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWrapperSettings() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Wrapper Settings',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Wrapper drivers provide compatibility layers for different GPU architectures.',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDriverFileSelection() {
    // Filter files based on selected driver type
    List<String> filteredFiles = [];
    
    if (_selectedDriverType == 'turnip') {
      filteredFiles = _driverFiles.where((file) => 
          file.toLowerCase().contains('turnip') || 
          file.toLowerCase().contains('freedreno')).toList();
    } else if (_selectedDriverType == 'virgl') {
      filteredFiles = _driverFiles.where((file) => 
          file.toLowerCase().contains('virgl') || 
          file.toLowerCase().contains('virtio')).toList();
    } else if (_selectedDriverType == 'wrapper') {
      filteredFiles = _driverFiles.where((file) => 
          file.toLowerCase().contains('wrapper') || 
          file.toLowerCase().contains('wine')).toList();
    }
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Select Driver File',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            
            if (_isLoading)
              const Center(child: CircularProgressIndicator()),
            
            if (!_isLoading && filteredFiles.isEmpty)
              const Column(
                children: [
                  Icon(Icons.error_outline, color: Colors.orange, size: 48),
                  SizedBox(height: 8),
                  Text(
                    'No driver files found',
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 4),
                  Text(
                    'Please place driver files in the drivers folder',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            
            if (!_isLoading && filteredFiles.isNotEmpty)
              DropdownButtonFormField<String>(
                value: _selectedDriverFile,
                decoration: const InputDecoration(
                  labelText: 'Driver File',
                  border: OutlineInputBorder(),
                ),
                items: filteredFiles.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedDriverFile = newValue;
                  });
                },
              ),
          ],
        ),
      ),
    );
  }
  

  Future<String> _checkVirglServerStatus() async {
    try {
      // Try to check if virgl_test_server is running
      final result = await Process.run('sh', ['-c', 'pgrep -f virgl_test_server']);
      final isRunning = result.stdout.toString().trim().isNotEmpty;
      
      return isRunning ? 'Running' : 'Not running';
    } catch (e) {
      // Fallback to showing the enabled state
      if (_virglEnabled && _selectedDriverType == 'virgl') {
        return 'Enabled (status unknown)';
      }
      return 'Disabled';
    }
  }
}